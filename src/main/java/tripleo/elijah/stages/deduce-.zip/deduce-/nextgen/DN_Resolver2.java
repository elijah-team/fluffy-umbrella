package tripleo.elijah.stages.deduce.nextgen;

public interface DN_Resolver2 {
	void resolve(DN_Resolver2 aResolver2);
}
