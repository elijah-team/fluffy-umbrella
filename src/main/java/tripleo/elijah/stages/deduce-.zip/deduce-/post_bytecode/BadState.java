package tripleo.elijah.stages.deduce.post_bytecode;

public class BadState extends RuntimeException {
}
