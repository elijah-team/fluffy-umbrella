package tripleo.elijah.stages.deduce.nextgen;

public interface DN_ResolverResolution {
	void apply();
}
