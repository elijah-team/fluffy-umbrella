package tripleo.elijah.stages.deduce;

import tripleo.elijah.stages.gen_fn.GeneratedClass;

@FunctionalInterface
public interface OnGenClass {
	void accept(final GeneratedClass aGeneratedClass);
}
