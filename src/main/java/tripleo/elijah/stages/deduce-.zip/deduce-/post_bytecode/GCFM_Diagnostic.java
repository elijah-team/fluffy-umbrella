package tripleo.elijah.stages.deduce.post_bytecode;

import tripleo.elijah.diagnostic.Diagnostic;

public interface GCFM_Diagnostic extends Diagnostic {
	String _message();
}
