package tripleo.elijah.stages.deduce.nextgen;

import tripleo.elijah.stages.gen_fn.BaseTableEntry;

public interface DN_ResolverRejection {
	void print_message(DN_Resolver aResolver, BaseTableEntry aBaseTableEntry);
}
