package tripleo.elijah.stages.deduce.fluffy.impl;

import tripleo.elijah.stages.deduce.fluffy.i.FluffyVarTarget;

public class FluffyVarTargetImpl implements FluffyVarTarget {
	@Override
	public T getT() {
		return null;
	}
}
