package tripleo.elijah.stages.deduce.fluffy.i;

import tripleo.elijah.ci.LibraryStatementPart;

public interface FluffyLsp {

	LibraryStatementPart getLsp();
}
